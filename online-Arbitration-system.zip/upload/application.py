from flask import Flask, render_template, request, render_template_string
import os
from werkzeug.utils import secure_filename
import unittest2
from threading import Thread
from Marker_valid import min_marker
import importlib.util


BASE_DIR = os.path.dirname(__file__)
app = Flask(__name__)


def module_from_file(module_name, file_path):
   spec = importlib.util.spec_from_file_location(module_name, file_path)
   module = importlib.util.module_from_spec(spec)
   spec.loader.exec_module(module)
   return module


@app.route('/')
def start():
    return render_template("Home.html")


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == "POST":
        f = request.files['uploadedData']
        up_dir = os.path.join(BASE_DIR+'\\UPLOADfiles')
        f.save(up_dir+f'/{secure_filename(f.filename)}')
        try:
            pth = str(up_dir + f'\\{secure_filename(f.filename)}')
            pyfile_test = module_from_file(f"{secure_filename(f.filename)}", pth)
            try:
                global fun
                fun = pyfile_test.lowest_marker
                return fun_test()
            except:
                return render_template('Upload.html', response="there is not similar function")
        except:
            return render_template("Upload.html", response="Error")
    return render_template('Upload.html')


def fun_test():
    thread = Thread()
    thread.start()
    run, error, fail = 0, [], []
    data = {3: ['1', '1', '2'], 5: ['1', '2', '1', '3', '4'], 9: ['3', '3', '3', '1', '1', '2', '2', '2', '4']}
    global first_input, second_input
    for i in data:
        first_input = i
        second_input = data[i]
        suite = unittest2.TestLoader().loadTestsFromTestCase(CallTest)
        testing_result = unittest2.TextTestRunner(verbosity=2).run(suite)
        error.extend(testing_result.errors)
        fail.extend(testing_result.failures)
    stop_threads = True
    thread.join()
    err_num = len(error)
    fal_num = len(fail)
    if error == [] and fail == []:
        return render_template('Upload.html', response="successful operation")
    else:
        return render_template('Upload.html', response=f"Failed: {fal_num}, ERROR: {err_num}")


class CallTest(unittest2.TestCase):
    def setUp(self):
        self.call = fun

    def test_marker(self):
        result = self.call(first_input, second_input)
        verify = min_marker(first_input, second_input)
        self.assertEqual(result, verify)


if __name__ == '__main__':
    app.run(debug=True, host="localhost", port="5001")


def min_marker(marker_num, marker_typ):
    if marker_num == len(marker_typ):
        types = list()
        count = dict()
        for typee in marker_typ:
            if typee not in types:
                types.append(typee)
                count[typee] = 1
            elif typee in types:
                count[typee] += 1
        types.sort()
        mini = int(types[0])
        for i in count:
            if count[i] < count[str(mini)]:
                mini = int(i)
        return mini

# print(min_marker(3, ))